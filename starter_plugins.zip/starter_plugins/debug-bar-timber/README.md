## Timber Debug Bar

Debug Bar Extension for the Timber Library. To use, you'll need the [WordPress Debug Bar](http://wordpress.org/plugins/debug-bar/)